package com.example.uttam_practical_7_1_2021

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
